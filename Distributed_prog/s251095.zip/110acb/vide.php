<!DOCTYPE html>

<html>
<head>

 <link rel="stylesheet" href="style.css" /> 

</head>
<body>  
 <h1 class='error' > ACTIVE YOUR COOCKIES AND/OR JAVA </h1>

</body>  
</html>
